import { createFileRoute } from "@tanstack/react-router";
import { ChronicleApp } from "@/components/chronicle/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ChronicleApp />;
}
