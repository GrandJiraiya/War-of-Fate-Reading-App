import { useEffect, useState } from "react";
import { Pause, Play, SkipBack, SkipForward } from "lucide-react";
import { acts } from "@/data/chronicle";
import { getAudio } from "@/lib/player";
import { useChronicle } from "@/state/chronicle";

function format(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const whole = Math.floor(seconds);
  const m = Math.floor(whole / 60);
  const s = whole % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function PlayerDock() {
  const tracks = useChronicle((s) => s.tracks);
  const currentId = useChronicle((s) => s.currentId);
  const playing = useChronicle((s) => s.playing);
  const volume = useChronicle((s) => s.volume);
  const toggle = useChronicle((s) => s.toggle);
  const next = useChronicle((s) => s.next);
  const prev = useChronicle((s) => s.prev);
  const setVol = useChronicle((s) => s.setVol);
  const setView = useChronicle((s) => s.setView);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const current = tracks.find((track) => track.id === currentId) ?? null;
  const act = current?.actId ? acts.find((item) => item.id === current.actId) : null;

  useEffect(() => {
    const el = getAudio();
    if (!el) return;
    const onTime = () => setTime(el.currentTime);
    const onMeta = () => setDuration(el.duration);
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("durationchange", onMeta);
    el.addEventListener("loadedmetadata", onMeta);
    return () => {
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("durationchange", onMeta);
      el.removeEventListener("loadedmetadata", onMeta);
    };
  }, [currentId]);

  return (
    <div className="mx-auto flex max-w-5xl items-center gap-3 px-3 py-2 md:px-6">
      <button
        type="button"
        onClick={() => void prev()}
        className="flex size-11 items-center justify-center text-mist"
        aria-label="Previous track"
        disabled={!tracks.length}
      >
        <SkipBack className="size-4" />
      </button>
      <button
        type="button"
        onClick={() => void toggle()}
        className="flex size-11 items-center justify-center bg-dawn text-ink"
        aria-label={playing ? "Pause" : "Play"}
        disabled={!tracks.length}
      >
        {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
      </button>
      <button
        type="button"
        onClick={() => void next()}
        className="flex size-11 items-center justify-center text-mist"
        aria-label="Next track"
        disabled={!tracks.length}
      >
        <SkipForward className="size-4" />
      </button>
      <button
        type="button"
        onClick={() => setView("score")}
        className="min-w-0 flex-1 text-left"
      >
        <p className="truncate font-display text-base text-bone">
          {current ? current.name : "The score is empty"}
        </p>
        <p className="truncate text-xs text-mist">
          {current
            ? act
              ? `Act ${act.numeral} · ${act.title}`
              : "Unassigned"
            : "Add the book’s soundtrack"}
        </p>
      </button>
      <label className="hidden items-center gap-2 text-xs text-mist md:flex">
        <span className="tabular-nums">{format(time)}</span>
        <input
          type="range"
          min={0}
          max={duration || 0}
          step={0.1}
          value={Math.min(time, duration || 0)}
          aria-label="Seek"
          disabled={!current || !duration}
          onChange={(event) => {
            const el = getAudio();
            if (!el) return;
            el.currentTime = Number(event.target.value);
            setTime(el.currentTime);
          }}
          className="w-28 accent-dawn"
        />
        <span className="tabular-nums">{format(duration)}</span>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={volume}
          aria-label="Volume"
          onChange={(event) => setVol(Number(event.target.value))}
          className="w-16 accent-dawn"
        />
      </label>
    </div>
  );
}
