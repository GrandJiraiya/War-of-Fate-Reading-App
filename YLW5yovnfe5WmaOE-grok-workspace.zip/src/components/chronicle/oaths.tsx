import { useRef, useState } from "react";
import { bearings, doctrines, forces } from "@/data/chronicle";
import { useChronicle } from "@/state/chronicle";

function distance(a: number, b: number) {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

export function OathsView() {
  const forceId = useChronicle((s) => s.forceId);
  const setForce = useChronicle((s) => s.setForce);
  const [deg, setDeg] = useState(18);
  const drag = useRef(false);
  const dial = useRef<HTMLDivElement>(null);
  const force = forces.find((item) => item.id === forceId) ?? forces[0];
  const nearest = bearings.reduce((best, item) =>
    distance(deg, item.deg) < distance(deg, best.deg) ? item : best,
  );
  const heard = distance(deg, nearest.deg) < 26;

  function fromEvent(clientX: number, clientY: number) {
    const el = dial.current;
    if (!el) return deg;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let next = (Math.atan2(clientX - cx, cy - clientY) * 180) / Math.PI;
    if (next < 0) next += 360;
    return next;
  }

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-dawn">Oaths</p>
      <h2 className="mt-2 max-w-3xl font-display text-4xl text-balance md:text-5xl">
        It does not point north
      </h2>
      <p className="mt-4 max-w-prose text-lg text-pretty text-mist">
        The shard-compass is splinters of Glass Oath in leather, tuned to the Pi Gate under Cock Fortress. Turn it. When it tugs close to a house, the house answers.
      </p>

      <div className="mt-8 grid items-center gap-8 md:grid-cols-[18rem_1fr]">
        <div
          ref={dial}
          role="slider"
          tabIndex={0}
          aria-valuemin={0}
          aria-valuemax={359}
          aria-valuenow={Math.round(deg)}
          aria-label="Shard-compass"
          className="relative mx-auto size-64 touch-none rounded-full border border-dawn/40 bg-ink"
          onPointerDown={(event) => {
            drag.current = true;
            event.currentTarget.setPointerCapture(event.pointerId);
            setDeg(fromEvent(event.clientX, event.clientY));
          }}
          onPointerMove={(event) => {
            if (!drag.current) return;
            setDeg(fromEvent(event.clientX, event.clientY));
          }}
          onPointerUp={() => {
            drag.current = false;
          }}
          onKeyDown={(event) => {
            if (event.key === "ArrowRight" || event.key === "ArrowUp") {
              event.preventDefault();
              setDeg((value) => (value + 12) % 360);
            }
            if (event.key === "ArrowLeft" || event.key === "ArrowDown") {
              event.preventDefault();
              setDeg((value) => (value - 12 + 360) % 360);
            }
          }}
        >
          <img
            src="/chronicle/compass.jpg"
            alt=""
            className="absolute top-1/2 left-1/2 size-24 -translate-x-1/2 -translate-y-1/2 rounded-full object-cover"
          />
          <span
            className="pointer-events-none absolute inset-0"
            style={{ transform: `rotate(${deg}deg)` }}
          >
            <span className="absolute top-2 left-1/2 h-28 w-px -translate-x-1/2 bg-dawn" />
          </span>
          <span className="pointer-events-none absolute top-2 left-1/2 -translate-x-1/2 text-xs text-dawn">
            tug
          </span>
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-mist">
            {heard ? "The tug lands" : "Still searching"}
          </p>
          <h3 className="mt-2 font-display text-3xl">{heard ? nearest.name : "Between oaths"}</h3>
          <p className="mt-3 max-w-prose text-lg text-pretty text-mist">
            {heard
              ? nearest.line
              : "Houses sit on the dial like old debts. Drag the glass, or choose one below."}
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            {bearings.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setDeg(item.deg)}
                className={
                  heard && nearest.id === item.id
                    ? "min-h-11 border border-dawn bg-dawn px-3 py-2 text-ink"
                    : "min-h-11 border border-dawn/30 px-3 py-2 text-bone"
                }
              >
                {item.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <h3 className="mt-14 font-display text-3xl">Primary forces</h3>
      <p className="mt-3 max-w-prose text-mist">
        Holy and Void have agendas. They are not automatic moral alignments. Nothing here has a level.
      </p>
      <div className="mt-5 grid gap-2 sm:grid-cols-3">
        {forces.map((item) => {
          const active = item.id === force.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setForce(item.id)}
              className={
                active
                  ? "min-h-11 border border-dawn bg-dawn/10 px-4 py-3 text-left font-display text-xl text-dawn"
                  : "min-h-11 border border-dawn/25 px-4 py-3 text-left font-display text-xl text-bone"
              }
              aria-pressed={active}
            >
              {item.name}
            </button>
          );
        })}
      </div>
      <p className="mt-4 max-w-prose text-lg text-pretty">{force.note}</p>

      <h3 className="mt-14 font-display text-3xl">What the words are holding</h3>
      <ul className="mt-4 divide-y divide-dawn/15 border-y border-dawn/15">
        {doctrines.map((item) => (
          <li key={item.name} className="grid gap-2 py-5 md:grid-cols-[12rem_1fr] md:gap-8">
            <p className="font-display text-xl text-dawn">{item.name}</p>
            <p className="text-pretty leading-relaxed">{item.note}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
