import { acts, chapterCount, summary } from "@/data/chronicle";
import { useChronicle } from "@/state/chronicle";

export function LedgerView() {
  const actId = useChronicle((s) => s.actId);
  const setAct = useChronicle((s) => s.setAct);
  const read = useChronicle((s) => s.read);
  const toggleRead = useChronicle((s) => s.toggleRead);
  const tracks = useChronicle((s) => s.tracks);
  const toggle = useChronicle((s) => s.toggle);
  const setView = useChronicle((s) => s.setView);
  const act = acts.find((item) => item.id === actId) ?? acts[0];
  const cue = tracks.find((track) => track.actId === act.id);
  const marked = read.length;

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-dawn">The ledger</p>
      <h2 className="mt-2 font-display text-4xl text-balance text-bone md:text-5xl">
        What the war is, before it spends you
      </h2>
      <div className="mt-8 max-w-prose space-y-5 text-lg leading-relaxed text-pretty">
        {summary.map((paragraph) => (
          <p key={paragraph.slice(0, 24)}>{paragraph}</p>
        ))}
      </div>
      <p className="mt-6 max-w-prose text-mist">
        The contents below are the book's own. Mark a chapter when you have read it — the marks stay in this browser. This companion does not tell you how the forty days end.
      </p>

      <div className="mt-8 flex items-end justify-between gap-4 border-t border-dawn/20 pt-4">
        <p className="font-display text-lg text-bone">
          <span className="tabular-nums text-dawn">{marked}</span>
          <span className="text-mist"> of {chapterCount} marked</span>
        </p>
      </div>
      <div className="mt-3 h-px bg-dawn/20">
        <div
          className="h-px bg-dawn"
          style={{ width: `${(marked / chapterCount) * 100}%` }}
        />
      </div>

      <div className="mt-8 -mx-5 flex gap-2 overflow-x-auto px-5 pb-2 md:mx-0 md:flex-wrap md:px-0">
        {acts.map((item) => {
          const active = item.id === act.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setAct(item.id)}
              className={
                active
                  ? "shrink-0 border border-dawn bg-dawn px-4 py-3 text-left text-ink"
                  : "shrink-0 border border-dawn/30 px-4 py-3 text-left text-bone"
              }
            >
              <span className="block text-xs uppercase tracking-widest">Act {item.numeral}</span>
              <span className="mt-1 block font-display text-lg">{item.title}</span>
            </button>
          );
        })}
      </div>

      <section className="mt-8 border-t border-dawn/20 pt-6" aria-labelledby="act-title">
        <p className="text-xs uppercase tracking-widest text-dawn">Act {act.numeral}</p>
        <h3 id="act-title" className="mt-2 font-display text-3xl text-balance">
          {act.title}
        </h3>
        <p className="mt-3 max-w-prose text-lg text-pretty text-mist">{act.frame}</p>
        <div className="mt-4 flex flex-wrap gap-3">
          {cue ? (
            <button
              type="button"
              onClick={() => void toggle(cue.id)}
              className="min-h-11 border border-dawn/40 px-4 py-2 font-display text-dawn"
            >
              Play “{cue.name}”
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setView("score")}
              className="min-h-11 border border-dawn/30 px-4 py-2 font-display text-mist"
            >
              Lay a cue on this act
            </button>
          )}
        </div>
        <ol className="mt-6 divide-y divide-dawn/15 border-y border-dawn/15">
          {act.chapters.map((chapter) => {
            const on = read.includes(chapter.id);
            return (
              <li key={chapter.id} className="flex items-center gap-4 py-2">
                <button
                  type="button"
                  aria-pressed={on}
                  aria-label={on ? `Unmark chapter ${chapter.n}` : `Mark chapter ${chapter.n} read`}
                  onClick={() => toggleRead(chapter.id)}
                  className={
                    on
                      ? "flex size-11 shrink-0 items-center justify-center rounded-full border border-dawn bg-dawn/15"
                      : "flex size-11 shrink-0 items-center justify-center rounded-full border border-dawn/35"
                  }
                >
                  <span className={on ? "size-2.5 rounded-full bg-dawn" : "size-2.5 rounded-full border border-dawn/40"} />
                </button>
                <div className="min-w-0">
                  <p className="text-xs tabular-nums text-mist">Chapter {chapter.n}</p>
                  <p className={on ? "font-display text-xl text-dawn" : "font-display text-xl text-bone"}>
                    {chapter.title}
                  </p>
                </div>
              </li>
            );
          })}
        </ol>
      </section>
    </div>
  );
}
