import { names, people, places } from "@/data/chronicle";
import { useChronicle } from "@/state/chronicle";

export function RealmView() {
  const placeId = useChronicle((s) => s.placeId);
  const setPlace = useChronicle((s) => s.setPlace);

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-dawn">The realm</p>
      <h2 className="mt-2 max-w-3xl font-display text-4xl text-balance md:text-5xl">
        Squack'Ka'Saar, before the maps argue
      </h2>
      <p className="mt-4 max-w-prose text-lg text-pretty text-mist">
        Five places from the opening of the war. Tap a plate. The rest of the realm is named further down, where the book has not yet asked for a portrait.
      </p>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {places.map((place) => {
          const open = placeId === place.id;
          return (
            <article key={place.id} className="border border-dawn/20 bg-panel">
              <button
                type="button"
                onClick={() => setPlace(open ? null : place.id)}
                className="block w-full text-left"
                aria-expanded={open}
              >
                <img
                  src={place.image}
                  alt={place.name}
                  className="aspect-video w-full object-cover"
                />
                <div className="px-4 py-4">
                  <p className="text-xs uppercase tracking-widest text-dawn">{place.region}</p>
                  <h3 className="mt-1 font-display text-2xl">{place.name}</h3>
                </div>
              </button>
              {open && <p className="px-4 pb-5 text-pretty leading-relaxed text-mist">{place.body}</p>}
            </article>
          );
        })}
      </div>

      <h3 className="mt-14 font-display text-3xl">Who is already in the fog</h3>
      <div className="mt-6 grid gap-8 md:grid-cols-3">
        {people.map((person) => (
          <article key={person.id}>
            {person.image && (
              <img
                src={person.image}
                alt={person.name}
                className="portrait w-full object-cover object-top"
              />
            )}
            <p className="mt-3 text-xs uppercase tracking-widest text-dawn">{person.role}</p>
            <h3 className="font-display text-3xl">{person.name}</h3>
            {person.quote && (
              <blockquote className="mt-3 border-l border-dawn pl-3 font-display text-lg italic text-pretty">
                {person.quote}
              </blockquote>
            )}
            <p className="mt-3 text-pretty leading-relaxed text-mist">{person.body}</p>
          </article>
        ))}
      </div>

      <h3 className="mt-14 font-display text-3xl">Also on the first pages</h3>
      <ul className="mt-4 divide-y divide-dawn/15 border-y border-dawn/15">
        {names.map((entry) => (
          <li key={entry.name} className="grid gap-1 py-4 md:grid-cols-[10rem_1fr] md:gap-6">
            <p className="font-display text-xl">{entry.name}</p>
            <p className="text-pretty text-mist">{entry.note}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
