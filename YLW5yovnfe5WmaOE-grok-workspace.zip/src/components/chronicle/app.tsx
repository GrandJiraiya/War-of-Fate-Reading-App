import { useEffect } from "react";
import { AudioLines, BookOpen, Compass, Map, ScrollText } from "lucide-react";
import { book } from "@/data/chronicle";
import { useChronicle, type ViewId } from "@/state/chronicle";
import { CoverView } from "@/components/chronicle/cover";
import { LedgerView } from "@/components/chronicle/ledger";
import { RealmView } from "@/components/chronicle/realm";
import { OathsView } from "@/components/chronicle/oaths";
import { ScoreView } from "@/components/chronicle/score";
import { PlayerDock } from "@/components/chronicle/dock";

const nav: { id: ViewId; label: string; icon: typeof BookOpen }[] = [
  { id: "cover", label: "Dawn", icon: BookOpen },
  { id: "ledger", label: "Ledger", icon: ScrollText },
  { id: "realm", label: "Realm", icon: Map },
  { id: "oaths", label: "Oaths", icon: Compass },
  { id: "score", label: "Score", icon: AudioLines },
];

export function ChronicleApp() {
  const view = useChronicle((s) => s.view);
  const setView = useChronicle((s) => s.setView);
  const hydrate = useChronicle((s) => s.hydrate);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  return (
    <div className="relative min-h-dvh bg-ink text-bone">
      <header
        className={
          view === "cover"
            ? "absolute inset-x-0 top-0 z-20 flex items-center justify-between gap-4 px-5 py-4 md:px-10"
            : "sticky top-0 z-20 flex items-center justify-between gap-4 border-b border-dawn/20 bg-ink/95 px-5 py-4 backdrop-blur-sm md:px-10"
        }
      >
        <button
          type="button"
          onClick={() => setView("cover")}
          className="text-left"
        >
          <span className="block font-display text-lg leading-none text-bone md:text-xl">
            {book.title}
          </span>
          <span className="mt-1 block text-xs uppercase tracking-widest text-dawn">
            {book.series}
          </span>
        </button>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Companion">
          {nav.map((item) => {
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={
                  active
                    ? "border-b border-dawn px-3 py-2 font-display text-bone"
                    : "border-b border-transparent px-3 py-2 font-display text-mist hover:text-bone"
                }
                aria-current={active ? "page" : undefined}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      </header>

      <main className={view === "cover" ? "" : "mx-auto max-w-5xl px-5 pt-8 pb-40 md:px-10 md:pt-12 md:pb-28"}>
        {view === "cover" && <CoverView />}
        {view === "ledger" && <LedgerView />}
        {view === "realm" && <RealmView />}
        {view === "oaths" && <OathsView />}
        {view === "score" && <ScoreView />}
      </main>

      <div className="dock fixed inset-x-0 bottom-0 z-30 border-t border-dawn/20 bg-panel">
        <PlayerDock />
        <nav className="grid grid-cols-5 border-t border-dawn/15 md:hidden" aria-label="Companion">
          {nav.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={
                  active
                    ? "flex min-h-16 flex-col items-center justify-center gap-1 text-dawn"
                    : "flex min-h-16 flex-col items-center justify-center gap-1 text-mist"
                }
                aria-current={active ? "page" : undefined}
              >
                <Icon className="size-5" strokeWidth={1.5} aria-hidden="true" />
                <span className="text-xs">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
