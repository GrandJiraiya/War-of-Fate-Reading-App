import { useState } from "react";
import { Pause, Play, Plus } from "lucide-react";
import { acts } from "@/data/chronicle";
import { useChronicle } from "@/state/chronicle";

export function ScoreView() {
  const tracks = useChronicle((s) => s.tracks);
  const addFiles = useChronicle((s) => s.addFiles);
  const assign = useChronicle((s) => s.assign);
  const rename = useChronicle((s) => s.rename);
  const remove = useChronicle((s) => s.remove);
  const armedDelete = useChronicle((s) => s.armedDelete);
  const armDelete = useChronicle((s) => s.armDelete);
  const toggle = useChronicle((s) => s.toggle);
  const currentId = useChronicle((s) => s.currentId);
  const playing = useChronicle((s) => s.playing);
  const atmosphere = useChronicle((s) => s.atmosphere);
  const toggleAtmosphere = useChronicle((s) => s.toggleAtmosphere);
  const [over, setOver] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-dawn">The score</p>
      <h2 className="mt-2 font-display text-4xl text-balance md:text-5xl">Lay the soundtrack in</h2>
      <p className="mt-4 max-w-prose text-lg text-pretty text-mist">
        Add music from the book's soundtrack. It stays in this browser and is never uploaded. Assign a movement to an act and it will be waiting when you open that part of the ledger.
      </p>

      <label
        onDragOver={(event) => {
          event.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setOver(false);
          void addFiles(event.dataTransfer.files);
        }}
        className={
          over
            ? "mt-8 flex min-h-36 cursor-pointer flex-col items-center justify-center border border-dawn bg-dawn/10 px-6 py-8 text-center"
            : "mt-8 flex min-h-36 cursor-pointer flex-col items-center justify-center border border-dashed border-dawn/40 px-6 py-8 text-center"
        }
      >
        <Plus className="size-5 text-dawn" aria-hidden="true" />
        <span className="mt-3 font-display text-2xl">Add tracks</span>
        <span className="mt-1 text-mist">Drop audio here, or choose files</span>
        <input
          type="file"
          accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus"
          multiple
          className="sr-only"
          onChange={(event) => {
            if (event.target.files) void addFiles(event.target.files);
            event.target.value = "";
          }}
        />
      </label>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border border-dawn/20 px-4 py-4">
        <div>
          <p className="font-display text-xl">Marsh room-tone</p>
          <p className="text-sm text-mist">A quiet bed of water and low strings until your score takes the room. Not part of the soundtrack.</p>
        </div>
        <button
          type="button"
          onClick={() => void toggleAtmosphere()}
          aria-pressed={atmosphere}
          className={
            atmosphere
              ? "min-h-11 bg-dawn px-4 py-2 font-display text-ink"
              : "min-h-11 border border-dawn/40 px-4 py-2 font-display text-bone"
          }
        >
          {atmosphere ? "Silence the marsh" : "Let the marsh breathe"}
        </button>
      </div>

      <h3 className="mt-12 font-display text-2xl">Cues</h3>
      <ul className="mt-3 divide-y divide-dawn/15 border-y border-dawn/15">
        {acts.map((act) => {
          const cue = tracks.find((track) => track.actId === act.id);
          return (
            <li key={act.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="text-xs uppercase tracking-widest text-dawn">Act {act.numeral}</p>
                <p className="font-display text-xl">{act.title}</p>
                <p className="text-sm text-mist">{cue ? cue.name : "Empty"}</p>
              </div>
              <div className="flex items-center gap-2">
                {cue && (
                  <button
                    type="button"
                    onClick={() => void toggle(cue.id)}
                    className="flex size-11 items-center justify-center border border-dawn/40 text-dawn"
                    aria-label={playing && currentId === cue.id ? `Pause ${cue.name}` : `Play ${cue.name}`}
                  >
                    {playing && currentId === cue.id ? (
                      <Pause className="size-4" aria-hidden="true" />
                    ) : (
                      <Play className="size-4" aria-hidden="true" />
                    )}
                  </button>
                )}
                <label className="min-h-11 cursor-pointer border border-dawn/30 px-3 py-2 text-sm text-bone">
                  {cue ? "Replace" : "Lay in"}
                  <input
                    type="file"
                    accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus"
                    className="sr-only"
                    onChange={(event) => {
                      if (event.target.files) void addFiles(event.target.files, act.id);
                      event.target.value = "";
                    }}
                  />
                </label>
              </div>
            </li>
          );
        })}
      </ul>

      <h3 className="mt-12 font-display text-2xl">Library</h3>
      {tracks.length === 0 ? (
        <p className="mt-3 text-mist">Nothing in the library yet.</p>
      ) : (
        <ul className="mt-3 divide-y divide-dawn/15 border-y border-dawn/15">
          {tracks.map((track) => {
            const live = currentId === track.id && playing;
            return (
              <li key={track.id} className="grid gap-3 py-4 md:grid-cols-[auto_1fr_auto] md:items-center">
                <button
                  type="button"
                  onClick={() => void toggle(track.id)}
                  className="flex size-11 items-center justify-center border border-dawn/40 text-dawn"
                  aria-label={live ? `Pause ${track.name}` : `Play ${track.name}`}
                >
                  {live ? <Pause className="size-4" /> : <Play className="size-4" />}
                </button>
                <div className="min-w-0">
                  {editing === track.id ? (
                    <input
                      autoFocus
                      defaultValue={track.name}
                      aria-label="Track name"
                      className="w-full border border-dawn/40 bg-ink px-3 py-2 text-bone"
                      onBlur={(event) => {
                        void rename(track.id, event.target.value);
                        setEditing(null);
                      }}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") event.currentTarget.blur();
                      }}
                    />
                  ) : (
                    <button
                      type="button"
                      onClick={() => setEditing(track.id)}
                      className="block max-w-full truncate text-left font-display text-xl"
                    >
                      {track.name}
                    </button>
                  )}
                  <label className="mt-2 block text-sm text-mist">
                    Cue
                    <select
                      value={track.actId ?? ""}
                      onChange={(event) => void assign(track.id, event.target.value || null)}
                      className="mt-1 block w-full border border-dawn/30 bg-ink px-3 py-2 text-bone"
                    >
                      <option value="">Unassigned</option>
                      {acts.map((act) => (
                        <option key={act.id} value={act.id}>
                          Act {act.numeral} — {act.title}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (armedDelete === track.id) void remove(track.id);
                    else armDelete(track.id);
                  }}
                  className="min-h-11 justify-self-start px-2 text-sm text-mist md:justify-self-end"
                >
                  {armedDelete === track.id ? "Remove this track?" : "Remove"}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
