import { useState } from "react";
import { book, opening, summary } from "@/data/chronicle";
import { useChronicle } from "@/state/chronicle";

export function CoverView() {
  const setView = useChronicle((s) => s.setView);
  const [open, setOpen] = useState(false);

  return (
    <section className="relative min-h-dvh">
      <img
        src="/chronicle/hero.jpg"
        alt="Reed Causeway at dawn, fog over black water, a rooster king watching a pale column"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-linear-to-t from-ink via-ink/75 to-ink/30" />
      <div className="absolute inset-x-0 top-0 h-36 bg-linear-to-b from-ink to-transparent" />
      <div className="relative flex min-h-dvh flex-col justify-end px-5 pt-28 pb-44 md:px-10 md:pb-36">
        <p className="text-xs uppercase tracking-widest text-dawn">
          {book.series} · {book.volume}
        </p>
        <h1 className="mt-3 max-w-4xl font-display text-6xl leading-none text-balance text-bone md:text-8xl">
          {book.title}
        </h1>
        <p className="mt-4 font-display text-2xl italic text-bone md:text-3xl">{book.motto}</p>
        <p className="mt-6 max-w-prose text-lg text-pretty text-bone/90">{summary[0]} {summary[1]}</p>
        <p className="mt-3 text-sm uppercase tracking-widest text-mist">
          {book.author} · {book.imprint}
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => setView("ledger")}
            className="min-h-11 bg-dawn px-5 py-3 font-display text-ink"
          >
            Open the ledger
          </button>
          <button
            type="button"
            onClick={() => setView("realm")}
            className="min-h-11 border border-dawn/50 px-5 py-3 font-display text-bone"
          >
            Walk the realm
          </button>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="min-h-11 px-5 py-3 font-display text-dawn"
            aria-expanded={open}
          >
            {open ? "Close the first line" : "The first line"}
          </button>
        </div>
        {open && (
          <blockquote className="mt-8 max-w-prose border-l border-dawn pl-4">
            <p className="font-display text-2xl italic text-balance text-bone">{opening.line}</p>
            <footer className="mt-2 text-sm text-mist">{opening.attr}</footer>
          </blockquote>
        )}
      </div>
    </section>
  );
}
