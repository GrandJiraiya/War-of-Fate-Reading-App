import { create } from "zustand";
import { acts } from "@/data/chronicle";
import {
  deleteTrack,
  getTrack,
  listTracks,
  patchTrack,
  putTrack,
  type TrackMeta,
} from "@/lib/score-db";
import {
  forgetUrl,
  pauseAudio,
  playStored,
  resumeAudio,
  setOnEnded,
  setVolume,
  startAtmosphere,
  stopAtmosphere,
} from "@/lib/player";

export type ViewId = "cover" | "ledger" | "realm" | "oaths" | "score";

const READ_KEY = "wof-read";
const VOL_KEY = "wof-vol";

type ChronicleState = {
  view: ViewId;
  actId: string;
  placeId: string | null;
  forceId: string;
  read: string[];
  tracks: TrackMeta[];
  currentId: string | null;
  playing: boolean;
  volume: number;
  atmosphere: boolean;
  armedDelete: string | null;
  setView: (view: ViewId) => void;
  setAct: (actId: string) => void;
  setPlace: (placeId: string | null) => void;
  setForce: (forceId: string) => void;
  toggleRead: (id: string) => void;
  hydrate: () => Promise<void>;
  addFiles: (files: FileList | File[], actId?: string | null) => Promise<void>;
  assign: (id: string, actId: string | null) => Promise<void>;
  rename: (id: string, name: string) => Promise<void>;
  remove: (id: string) => Promise<void>;
  armDelete: (id: string | null) => void;
  play: (id: string) => Promise<void>;
  toggle: (id?: string) => Promise<void>;
  next: () => Promise<void>;
  prev: () => Promise<void>;
  setVol: (volume: number) => void;
  toggleAtmosphere: () => Promise<void>;
};

export function playOrder(tracks: TrackMeta[]) {
  const cued = acts
    .map((act) => tracks.find((track) => track.actId === act.id))
    .filter((track): track is TrackMeta => Boolean(track));
  const loose = tracks.filter((track) => !track.actId);
  return [...cued, ...loose];
}

export const useChronicle = create<ChronicleState>((set, get) => ({
  view: "cover",
  actId: acts[0].id,
  placeId: null,
  forceId: "void",
  read: [],
  tracks: [],
  currentId: null,
  playing: false,
  volume: 0.85,
  atmosphere: false,
  armedDelete: null,
  setView: (view) => {
    set({ view });
    if (typeof window !== "undefined") window.scrollTo(0, 0);
  },
  setAct: (actId) => set({ actId }),
  setPlace: (placeId) => set({ placeId }),
  setForce: (forceId) => set({ forceId }),
  toggleRead: (id) => {
    const read = get().read.includes(id)
      ? get().read.filter((item) => item !== id)
      : [...get().read, id];
    set({ read });
    try {
      localStorage.setItem(READ_KEY, JSON.stringify(read));
    } catch {
      /* private mode */
    }
  },
  hydrate: async () => {
    let volume = get().volume;
    let read: string[] = [];
    try {
      const storedVol = localStorage.getItem(VOL_KEY);
      if (storedVol) {
        const n = Number(storedVol);
        if (!Number.isNaN(n)) volume = Math.min(1, Math.max(0, n));
      }
      const storedRead = localStorage.getItem(READ_KEY);
      if (storedRead) {
        const parsed = JSON.parse(storedRead) as unknown;
        if (Array.isArray(parsed)) read = parsed.filter((item) => typeof item === "string");
      }
    } catch {
      /* ignore */
    }
    setVolume(volume);
    const tracks = await listTracks();
    set({ volume, read, tracks });
    setOnEnded(() => {
      const state = get();
      const order = playOrder(state.tracks);
      const idx = order.findIndex((track) => track.id === state.currentId);
      const next = order[idx + 1];
      if (next) void state.play(next.id);
      else set({ playing: false });
    });
  },
  addFiles: async (files, actId = null) => {
    const list = Array.from(files).filter(
      (file) => file.type.startsWith("audio/") || /\.(mp3|m4a|aac|wav|ogg|flac|opus)$/i.test(file.name),
    );
    let hold = actId ? (get().tracks.find((track) => track.actId === actId)?.id ?? null) : null;
    for (const file of list) {
      const data = await file.arrayBuffer();
      const id = crypto.randomUUID();
      if (hold) {
        await patchTrack(hold, { actId: null });
        hold = null;
      }
      await putTrack({
        id,
        name: file.name.replace(/\.[^/.]+$/, ""),
        actId,
        mime: file.type || "audio/mpeg",
        created: Date.now(),
        data,
      });
      if (actId) hold = id;
    }
    set({ tracks: await listTracks() });
  },
  assign: async (id, actId) => {
    if (actId) {
      const holder = get().tracks.find((track) => track.actId === actId && track.id !== id);
      if (holder) await patchTrack(holder.id, { actId: null });
    }
    await patchTrack(id, { actId });
    set({ tracks: await listTracks() });
  },
  rename: async (id, name) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    await patchTrack(id, { name: trimmed });
    set({ tracks: await listTracks() });
  },
  remove: async (id) => {
    forgetUrl(id);
    await deleteTrack(id);
    const tracks = await listTracks();
    const currentId = get().currentId === id ? null : get().currentId;
    set({
      tracks,
      currentId,
      playing: currentId ? get().playing : false,
      armedDelete: null,
    });
  },
  armDelete: (id) => set({ armedDelete: id }),
  play: async (id) => {
    const track = await getTrack(id);
    if (!track) return;
    try {
      await playStored(track, get().volume);
      set({ currentId: id, playing: true });
    } catch {
      set({ currentId: id, playing: false });
    }
  },
  toggle: async (id) => {
    const state = get();
    const target = id ?? state.currentId;
    if (!target) {
      const first = playOrder(state.tracks)[0];
      if (first) await state.play(first.id);
      return;
    }
    if (state.currentId === target && state.playing) {
      pauseAudio();
      set({ playing: false });
      return;
    }
    if (state.currentId === target && !state.playing) {
      try {
        await resumeAudio();
        set({ playing: true });
      } catch {
        await state.play(target);
      }
      return;
    }
    await state.play(target);
  },
  next: async () => {
    const order = playOrder(get().tracks);
    if (!order.length) return;
    const idx = order.findIndex((track) => track.id === get().currentId);
    const next = order[(idx + 1) % order.length];
    if (next) await get().play(next.id);
  },
  prev: async () => {
    const order = playOrder(get().tracks);
    if (!order.length) return;
    const idx = order.findIndex((track) => track.id === get().currentId);
    const prev = order[(idx - 1 + order.length) % order.length];
    if (prev) await get().play(prev.id);
  },
  setVol: (volume) => {
    const next = Math.min(1, Math.max(0, volume));
    setVolume(next);
    set({ volume: next });
    try {
      localStorage.setItem(VOL_KEY, String(next));
    } catch {
      /* ignore */
    }
  },
  toggleAtmosphere: async () => {
    if (get().atmosphere) {
      stopAtmosphere();
      set({ atmosphere: false });
      return;
    }
    await startAtmosphere();
    set({ atmosphere: true });
  },
}));
