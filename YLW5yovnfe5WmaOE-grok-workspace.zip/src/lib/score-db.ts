export type StoredTrack = {
  id: string;
  name: string;
  actId: string | null;
  mime: string;
  created: number;
  data: ArrayBuffer;
};

export type TrackMeta = Omit<StoredTrack, "data">;

const DB_NAME = "war-of-fate-score";
const STORE = "tracks";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the score."));
  });
}

export async function listTracks(): Promise<TrackMeta[]> {
  if (typeof indexedDB === "undefined") return [];
  const db = await openDb();
  const rows = await new Promise<StoredTrack[]>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result as StoredTrack[]);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return rows
    .map(({ data: _data, ...meta }) => meta)
    .sort((a, b) => a.created - b.created);
}

export async function getTrack(id: string): Promise<StoredTrack | null> {
  if (typeof indexedDB === "undefined") return null;
  const db = await openDb();
  const row = await new Promise<StoredTrack | undefined>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve(req.result as StoredTrack | undefined);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return row ?? null;
}

export async function putTrack(track: StoredTrack): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.objectStore(STORE).put(track);
  });
  db.close();
}

export async function patchTrack(
  id: string,
  patch: Partial<Pick<StoredTrack, "name" | "actId">>,
): Promise<void> {
  const existing = await getTrack(id);
  if (!existing) return;
  await putTrack({ ...existing, ...patch });
}

export async function deleteTrack(id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.objectStore(STORE).delete(id);
  });
  db.close();
}
