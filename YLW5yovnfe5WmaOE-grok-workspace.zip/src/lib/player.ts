import type { StoredTrack } from "@/lib/score-db";

const urls = new Map<string, string>();
let audio: HTMLAudioElement | null = null;
let onEnded: () => void = () => {};

export function getAudio(): HTMLAudioElement | null {
  if (typeof window === "undefined") return null;
  if (!audio) {
    audio = new Audio();
    audio.preload = "auto";
    audio.addEventListener("ended", () => onEnded());
  }
  return audio;
}

export function setOnEnded(fn: () => void) {
  onEnded = fn;
}

export function setVolume(volume: number) {
  const el = getAudio();
  if (el) el.volume = volume;
}

export async function playStored(track: StoredTrack, volume: number) {
  const el = getAudio();
  if (!el) return;
  let url = urls.get(track.id);
  if (!url) {
    const copy = track.data.slice(0);
    url = URL.createObjectURL(new Blob([copy], { type: track.mime || "audio/mpeg" }));
    urls.set(track.id, url);
  }
  if (el.src !== url) {
    el.src = url;
  }
  el.volume = volume;
  await el.play();
}

export function pauseAudio() {
  getAudio()?.pause();
}

export function resumeAudio() {
  return getAudio()?.play();
}

export function forgetUrl(id: string) {
  const url = urls.get(id);
  if (!url) return;
  if (audio && audio.src === url) {
    audio.pause();
    audio.removeAttribute("src");
    audio.load();
  }
  URL.revokeObjectURL(url);
  urls.delete(id);
}

let ctx: AudioContext | null = null;
let noise: AudioBufferSourceNode | null = null;
let oscA: OscillatorNode | null = null;
let oscB: OscillatorNode | null = null;
let master: GainNode | null = null;

export function stopAtmosphere() {
  try {
    noise?.stop();
  } catch {
    /* already stopped */
  }
  try {
    oscA?.stop();
  } catch {
    /* already stopped */
  }
  try {
    oscB?.stop();
  } catch {
    /* already stopped */
  }
  noise = null;
  oscA = null;
  oscB = null;
  master?.disconnect();
  master = null;
}

export async function startAtmosphere() {
  stopAtmosphere();
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return;
  ctx = ctx ?? new AC();
  if (ctx.state === "suspended") await ctx.resume();

  master = ctx.createGain();
  master.gain.value = 0.04;
  master.connect(ctx.destination);

  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const channel = buffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) channel[i] = Math.random() * 2 - 1;

  noise = ctx.createBufferSource();
  noise.buffer = buffer;
  noise.loop = true;
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 380;
  const noiseGain = ctx.createGain();
  noiseGain.gain.value = 0.4;
  noise.connect(filter);
  filter.connect(noiseGain);
  noiseGain.connect(master);
  noise.start();

  const tone = (freq: number, gain: number) => {
    const osc = ctx!.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const g = ctx!.createGain();
    g.gain.value = gain;
    osc.connect(g);
    g.connect(master!);
    osc.start();
    return osc;
  };
  oscA = tone(73, 0.22);
  oscB = tone(110, 0.08);
}

export function atmosphereLive() {
  return master !== null;
}
