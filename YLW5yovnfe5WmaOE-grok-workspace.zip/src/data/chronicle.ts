export const book = {
  title: "War of Fate",
  series: "Oath of the Peck",
  volume: "Book I",
  motto: "We Rise at Dawn.",
  author: "Crash",
  imprint: "Crash Out Studios",
  realm: "Squack\u2019Ka\u2019Saar",
  realmGloss: "The Crow Realm",
};

export const summary = [
  "War of Fate opens on the first dawn of the Forty-Day War.",
  "Pale Dawn \u2014 Legless\u2019s oath-bound host \u2014 sends a probe down Reed Causeway into Crow Marsh, dressed like a tax visit. Old King Karl of Wet Peck has spent three nights cutting the road out from under them. He does not call what follows a victory. He calls it a greeting, and he sends that greeting upriver to Cock Fortress.",
  "Prince Nezz takes the gray road between marsh and fortress with the shard-compass on his wrist: splinters of Glass Oath, tuned to the Pi Gate under the walls. It does not point. It tugs. In the quiet of his skull, Yezmir, the Void King, listens \u2014 and answers when Nezz would rather be counting knives.",
  "Squack\u2019Ka\u2019Saar is already arguing with itself. House of Cock holds Crowmania from Cock Castle. House of Hen sits in the Eastern Hills, bound in by Queen Lucy\u2019s marriage. House of Wells keeps Deepwell, the mines, and knowledge old enough to be rude. House Greenwood watches the forest crossings. Zilla trades under the Echo Dome. The Choir studies thresholds with sound, repetition, and pain.",
  "The book moves in rotating close third, through ledgers, witness, and recovered fragments. Power is echo, pressure, and cost \u2014 never a number. Some of what the realm believes on the morning of day one will not survive the forty days.",
];

export const opening = {
  line: "The marsh always took its tithe.",
  attr: "King Karl, Reed Causeway, day one",
};

export type Chapter = { id: string; n: number; title: string };

export type Act = {
  id: string;
  numeral: string;
  title: string;
  frame: string;
  chapters: Chapter[];
};

export const acts: Act[] = [
  {
    id: "west",
    numeral: "I",
    title: "West Stirs",
    frame:
      "Day one. The western edge stops being a rumor. Karl meets Pale Dawn in the fog, and Nezz is sent to look.",
    chapters: [
      { id: "1", n: 1, title: "The First Day of Forty" },
      { id: "2", n: 2, title: "The Scouting Line" },
      { id: "3", n: 3, title: "What Deepwell Saw" },
      { id: "4", n: 4, title: "The Castle That Thinks It Has Time" },
      { id: "5", n: 5, title: "Crow \u2019n Dawn" },
      { id: "6", n: 6, title: "Mr. Peck\u2019s Problem" },
      { id: "7", n: 7, title: "Frost in the Alley" },
      { id: "8", n: 8, title: "Orders at Dawn" },
    ],
  },
  {
    id: "echoes",
    numeral: "II",
    title: "Echoes Gather",
    frame:
      "Ward, river-bones, the Echo Dome, and a Choir that keeps its books in sound.",
    chapters: [
      { id: "9", n: 9, title: "Talon\u2019s Ward" },
      { id: "10", n: 10, title: "Turt and the Bones of the River" },
      { id: "11", n: 11, title: "Echo-Dome Chains" },
      { id: "12", n: 12, title: "The Choir\u2019s Ledger" },
      { id: "13", n: 13, title: "Little Spoon, Heavy Pockets" },
      { id: "14", n: 14, title: "Pockets Full of Rumors" },
      { id: "15", n: 15, title: "A Choir Needs a Blade" },
      { id: "16", n: 16, title: "The Infirmary Door" },
      { id: "17", n: 17, title: "Levers and Ledger Ink" },
    ],
  },
  {
    id: "circles",
    numeral: "III",
    title: "The First Circles",
    frame:
      "Older circles. What the realm says about Yezmir, the labyrinth, and the mirrors under Zilla is the public version.",
    chapters: [
      { id: "18", n: 18, title: "The First Circles" },
      { id: "19", n: 19, title: "Year Five of King Yezmir" },
      { id: "20", n: 20, title: "Whispers of the Labyrinth" },
      { id: "21", n: 21, title: "Mirrors Under Zilla" },
      { id: "22", n: 22, title: "The Tablets That Choose You" },
      { id: "23", n: 23, title: "The Priest Who Asked Wrong" },
    ],
  },
  {
    id: "keys",
    numeral: "IV",
    title: "Keys in the Dark",
    frame: "Cliffs, high boughs, a harbor without a ferryman, and a boundary.",
    chapters: [
      { id: "24", n: 24, title: "The Old Rooster on the Cliff" },
      { id: "25", n: 25, title: "Linda of the High Boughs" },
      { id: "26", n: 26, title: "Bones of First Light" },
      { id: "27", n: 27, title: "Harbor Without a Ferryman" },
      { id: "28", n: 28, title: "Linda in the Green Teeth" },
      { id: "29", n: 29, title: "Steel and Shadows" },
      { id: "30", n: 30, title: "The River\u2019s Edge" },
      { id: "31", n: 31, title: "The Boundary" },
    ],
  },
  {
    id: "marsh",
    numeral: "V",
    title: "The Marsh Speaks",
    frame: "Crow Marsh stops being scenery. Pale Dawn learns what a river can refuse.",
    chapters: [
      { id: "32", n: 32, title: "Marshal of the Marsh" },
      { id: "33", n: 33, title: "The Crow\u2019s Call" },
      { id: "34", n: 34, title: "The Marsh Wakes" },
      { id: "35", n: 35, title: "Retreat of the Pale Dawn" },
      { id: "36", n: 36, title: "Tiding the War" },
      { id: "37", n: 37, title: "The Ice Queen\u2019s Choice" },
    ],
  },
  {
    id: "river",
    numeral: "VI",
    title: "River Lies",
    frame: "Blood on the hands, lies in the water, and the fortress beginning to fill.",
    chapters: [
      { id: "38", n: 38, title: "Hands in the Blood" },
      { id: "39", n: 39, title: "River Lies" },
      { id: "40", n: 40, title: "The Fortress Gathers" },
      { id: "41", n: 41, title: "March of the King" },
      { id: "42", n: 42, title: "The Queen in the Shadows" },
      { id: "43", n: 43, title: "Pilgrim\u2019s Gate Alarm" },
    ],
  },
  {
    id: "cross",
    numeral: "VII",
    title: "Crossroads",
    frame: "An oath spoken aloud. A road back to Zilla. A council of stone.",
    chapters: [
      { id: "44", n: 44, title: "Crossroads in the Marsh" },
      { id: "45", n: 45, title: "The Oath I Spoke" },
      { id: "46", n: 46, title: "The Road Back to Zilla" },
      { id: "47", n: 47, title: "Knife and Kiss" },
      { id: "48", n: 48, title: "The Council of Stone" },
    ],
  },
  {
    id: "siege",
    numeral: "VIII",
    title: "The Siege",
    frame:
      "The war\u2019s last pressure lands on the Throat beneath Cock Fortress. The companion will not tell you the price.",
    chapters: [
      { id: "49", n: 49, title: "The Throat Gives" },
      { id: "50", n: 50, title: "The Road of Shields" },
      { id: "51", n: 51, title: "Winter on the Parapet" },
      { id: "52", n: 52, title: "Debt Collection" },
      { id: "53", n: 53, title: "The King\u2019s Price" },
      { id: "54", n: 54, title: "The Break in the Vessel" },
      { id: "55", n: 55, title: "Ice That Loves" },
      { id: "56", n: 56, title: "Dawn\u2019s Edge Aftermath" },
      { id: "57", n: 57, title: "The Ledger Doesn\u2019t Pray" },
      { id: "58", n: 58, title: "The Cliffsmith\u2019s Rule" },
      { id: "59", n: 59, title: "The Aster Mirror" },
    ],
  },
];

export const chapterCount = acts.reduce((n, act) => n + act.chapters.length, 0);

export type Place = {
  id: string;
  name: string;
  region: string;
  image: string;
  body: string;
};

export const places: Place[] = [
  {
    id: "causeway",
    name: "Reed Causeway",
    region: "Crow Marsh",
    image: "/chronicle/hero.jpg",
    body: "A ribbon of half-stone, half-log road across black water toward the Crow River. On the first day of forty, Karl\u2019s people drop the middle of it. The marsh corrects anyone who thinks the water is safer than the arrows. He writes it down as a greeting, not a victory.",
  },
  {
    id: "wetpeck",
    name: "Wet Peck",
    region: "Crow Marsh",
    image: "/chronicle/wetpeck.jpg",
    body: "The marsh seat of Old King Karl. Wet Peck fights with river, reed, mud, and ambush, and it keeps one eye on Orin \u2014 the god-turtle under the water \u2014 in the hope he stays asleep.",
  },
  {
    id: "fortress",
    name: "Cock Fortress",
    region: "The Throat",
    image: "/chronicle/fortress.jpg",
    body: "The forward defense of Crowmania, crouched on its ridge between Crow Marsh, the Red Ditch approaches, and Pilgrim\u2019s Gate. A Pi Gate is sealed beneath it. The shard-compass on Nezz\u2019s wrist is tuned to that home-note. The Forty-Day War runs toward the siege of this place.",
  },
  {
    id: "deepwell",
    name: "Deepwell",
    region: "The Stone Hills",
    image: "/chronicle/deepwell.jpg",
    body: "House of Wells. A mine-city descending through layers of contested stone, holding routes, ore, and old knowledge the other houses would prefer stayed buried.",
  },
  {
    id: "pale",
    name: "Pale Dawn",
    region: "The western host",
    image: "/chronicle/pale.jpg",
    body: "Legless\u2019s column: disciplined, oath-bound, and allied with forces that treat conquest as holy correction. They arrive looking like a tax visit. Karl says that is the dangerous part.",
  },
];

export type Person = {
  id: string;
  name: string;
  role: string;
  image?: string;
  quote?: string;
  body: string;
};

export const people: Person[] = [
  {
    id: "nezz",
    name: "Nezz",
    role: "Prince of House Cock",
    image: "/chronicle/nezz.jpg",
    quote: "A prince should look unbothered even when he\u2019s counting knives.",
    body: "Indigo\u2019s tutors trained the posture. The shard-compass on his left wrist is less obedient: splinters of Glass Oath that tug when other Glass, other Gates, or other things move too fast. He rides the road between Crow Marsh and Cock Fortress with Goss at his shoulder and a dead god in his skull.",
  },
  {
    id: "karl",
    name: "Karl",
    role: "Old King of Wet Peck",
    image: "/chronicle/karl.jpg",
    quote: "This wasn\u2019t a victory. It was a greeting.",
    body: "He wears lacquered marsh-steel, not pretty plate. He counts the dead, spits a small offering to the turtle under the water, and sends his son upriver with the first word of the war. Fortresses, he says, don\u2019t like owing rivers.",
  },
  {
    id: "yezmir",
    name: "Yezmir",
    role: "The Void King",
    image: "/chronicle/yezmir.jpg",
    quote:
      "You built your fortress on a door and then act surprised when the draft comes through.",
    body: "Pronounced YEZ-meer. His presence presses against Nezz through silence, temptation, inheritance, and promises of merciful absence. He is not a companion. He is a pressure with a voice like old parchment, and he prefers to speak when the living are trying to be quiet.",
  },
];

export const names = [
  {
    name: "Indigo",
    note: "Lord of the fortress that stares down the river. His men wear cleaner plate than Karl\u2019s. His tutors taught Nezz how to look calm.",
  },
  {
    name: "Goss",
    note: "The old captain. He has not let Nezz out of arm\u2019s reach since the rumors started sticking to the prince\u2019s shadow.",
  },
  {
    name: "Drix",
    note: "Karl\u2019s son. The armor is still almost too clean. He carries day one up the inland road.",
  },
  {
    name: "Queen Lucy",
    note: "The political marriage that binds House of Hen, and the Eastern Hills, to House of Cock.",
  },
  {
    name: "Orin",
    note: "God-turtle of Crow Marsh. Twenty stories when he wishes. Karl feels him the way you feel a storm behind your shoulder, and would like him to keep napping.",
  },
  {
    name: "Legless",
    note: "The name on Pale Dawn. On the second day he is still a color in the fog and the reason scouts are riding.",
  },
];

export type Bearing = { id: string; deg: number; name: string; line: string };

export const bearings: Bearing[] = [
  {
    id: "cock",
    deg: 0,
    name: "House of Cock",
    line: "Crowmania. Cock Castle, Roost Keep, Crow Harbor, Pilgrim\u2019s Gate, and the fortress on the Throat.",
  },
  {
    id: "hen",
    deg: 51,
    name: "House of Hen",
    line: "The eastern crown. Kockenflocker and the Eastern Hills, tied to Cock by Queen Lucy\u2019s marriage.",
  },
  {
    id: "wells",
    deg: 102,
    name: "House of Wells",
    line: "Deepwell and the Stone Hills. Stone, mines, routes, and dangerous old knowledge.",
  },
  {
    id: "green",
    deg: 154,
    name: "House Greenwood",
    line: "Scratch Forest and Echo Forest. Neutral crossings and older living boundaries.",
  },
  {
    id: "pale",
    deg: 205,
    name: "Pale Dawn",
    line: "Legless\u2019s host. Disciplined, oath-bound, and convinced conquest can be a holy correction.",
  },
  {
    id: "choir",
    deg: 257,
    name: "The Choir",
    line: "Sound, pain, repetition, and forced response \u2014 a doctrine for studying thresholds and living vessels.",
  },
  {
    id: "zilla",
    deg: 308,
    name: "Zilla",
    line: "A free city on the Echo Dome. Trade, spectacle, criminal leverage, and powers older than the arenas.",
  },
];

export const forces = [
  {
    id: "fire",
    name: "Fire",
    note: "A primary force. The realm records the cost, not a rank.",
  },
  {
    id: "frost",
    name: "Frost",
    note: "May preserve, expose, restrain, or deny.",
  },
  {
    id: "wind",
    name: "Wind",
    note: "A primary force. Felt as pressure before it is named.",
  },
  {
    id: "earth",
    name: "Earth",
    note: "A primary force. Stone keeps its own counsel, especially under Deepwell.",
  },
  {
    id: "void",
    name: "Void",
    note: "Speed, silence, absence, and merciful escape. An agenda, not a morality. Yezmir\u2019s country.",
  },
  {
    id: "light",
    name: "Light",
    note: "Holy is a force with an agenda, not an automatic good. Arcolos is dawn, oath, judgment, protection, and the terrible mercy of light.",
  },
  {
    id: "sound",
    name: "Sound",
    note: "The Choir\u2019s instrument: repetition, pain, and a response that is not quite a choice.",
  },
  {
    id: "lightning",
    name: "Lightning",
    note: "A primary force. The oath attached to it is the part that matters.",
  },
  {
    id: "water",
    name: "Water",
    note: "A primary force, and the marsh\u2019s oldest argument. On the causeway it is made to boil. Orin is not consulted.",
  },
];

export const doctrines = [
  {
    name: "Glass Oath",
    note: "A binding spiritual contract. Power comes through an element, a deity, or a governing principle, and every oath carries an obligation. Breaking one, bending one, or exploiting one has a spiritual cost and a practical one.",
  },
  {
    name: "Echo",
    note: "The pressure of a person\u2019s power, emotion, oath-condition, and intent. Echoes are sensed. They are never measured as a number.",
  },
  {
    name: "Pi Gate",
    note: "A sealed threshold under the deeper conflict. Old warnings say it is not opened by force, blood, or command. It judges.",
  },
  {
    name: "Shard-compass",
    note: "Splinters of Glass Oath bound in leather and thread, tuned to the Pi Gate beneath Cock Fortress. Less a north and more a home-note. It tugs.",
  },
  {
    name: "Choice-trace",
    note: "The residue of a consequential decision: oath, betrayal, mercy, refusal, or sacrifice.",
  },
  {
    name: "Arcolos",
    note: "AR-koh-lohs. Holy god of Squack\u2019Ka\u2019Saar. Dawn, oath, judgment, protection, and the terrible mercy of light.",
  },
];
