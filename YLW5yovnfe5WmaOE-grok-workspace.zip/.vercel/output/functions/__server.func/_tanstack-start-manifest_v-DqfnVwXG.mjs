//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DqfnVwXG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DOCgA9jp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DOCgA9jp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Br2BIJ2v.js"]
	}
} });
//#endregion
export { tsrStartManifest };
