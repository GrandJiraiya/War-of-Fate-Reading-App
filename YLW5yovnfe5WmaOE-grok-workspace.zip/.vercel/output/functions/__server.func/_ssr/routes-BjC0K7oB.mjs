import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Map$1, d as AudioLines, i as ScrollText, l as Compass, n as SkipForward, o as Play, r as SkipBack, s as Pause, u as BookOpen } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BjC0K7oB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var book = {
	title: "War of Fate",
	series: "Oath of the Peck",
	volume: "Book I",
	motto: "We Rise at Dawn.",
	author: "Crash",
	imprint: "Crash Out Studios",
	realm: "Squack’Ka’Saar",
	realmGloss: "The Crow Realm"
};
var summary = [
	"War of Fate opens on the first dawn of the Forty-Day War.",
	"Pale Dawn — Legless’s oath-bound host — sends a probe down Reed Causeway into Crow Marsh, dressed like a tax visit. Old King Karl of Wet Peck has spent three nights cutting the road out from under them. He does not call what follows a victory. He calls it a greeting, and he sends that greeting upriver to Cock Fortress.",
	"Prince Nezz takes the gray road between marsh and fortress with the shard-compass on his wrist: splinters of Glass Oath, tuned to the Pi Gate under the walls. It does not point. It tugs. In the quiet of his skull, Yezmir, the Void King, listens — and answers when Nezz would rather be counting knives.",
	"Squack’Ka’Saar is already arguing with itself. House of Cock holds Crowmania from Cock Castle. House of Hen sits in the Eastern Hills, bound in by Queen Lucy’s marriage. House of Wells keeps Deepwell, the mines, and knowledge old enough to be rude. House Greenwood watches the forest crossings. Zilla trades under the Echo Dome. The Choir studies thresholds with sound, repetition, and pain.",
	"The book moves in rotating close third, through ledgers, witness, and recovered fragments. Power is echo, pressure, and cost — never a number. Some of what the realm believes on the morning of day one will not survive the forty days."
];
var opening = {
	line: "The marsh always took its tithe.",
	attr: "King Karl, Reed Causeway, day one"
};
var acts = [
	{
		id: "west",
		numeral: "I",
		title: "West Stirs",
		frame: "Day one. The western edge stops being a rumor. Karl meets Pale Dawn in the fog, and Nezz is sent to look.",
		chapters: [
			{
				id: "1",
				n: 1,
				title: "The First Day of Forty"
			},
			{
				id: "2",
				n: 2,
				title: "The Scouting Line"
			},
			{
				id: "3",
				n: 3,
				title: "What Deepwell Saw"
			},
			{
				id: "4",
				n: 4,
				title: "The Castle That Thinks It Has Time"
			},
			{
				id: "5",
				n: 5,
				title: "Crow ’n Dawn"
			},
			{
				id: "6",
				n: 6,
				title: "Mr. Peck’s Problem"
			},
			{
				id: "7",
				n: 7,
				title: "Frost in the Alley"
			},
			{
				id: "8",
				n: 8,
				title: "Orders at Dawn"
			}
		]
	},
	{
		id: "echoes",
		numeral: "II",
		title: "Echoes Gather",
		frame: "Ward, river-bones, the Echo Dome, and a Choir that keeps its books in sound.",
		chapters: [
			{
				id: "9",
				n: 9,
				title: "Talon’s Ward"
			},
			{
				id: "10",
				n: 10,
				title: "Turt and the Bones of the River"
			},
			{
				id: "11",
				n: 11,
				title: "Echo-Dome Chains"
			},
			{
				id: "12",
				n: 12,
				title: "The Choir’s Ledger"
			},
			{
				id: "13",
				n: 13,
				title: "Little Spoon, Heavy Pockets"
			},
			{
				id: "14",
				n: 14,
				title: "Pockets Full of Rumors"
			},
			{
				id: "15",
				n: 15,
				title: "A Choir Needs a Blade"
			},
			{
				id: "16",
				n: 16,
				title: "The Infirmary Door"
			},
			{
				id: "17",
				n: 17,
				title: "Levers and Ledger Ink"
			}
		]
	},
	{
		id: "circles",
		numeral: "III",
		title: "The First Circles",
		frame: "Older circles. What the realm says about Yezmir, the labyrinth, and the mirrors under Zilla is the public version.",
		chapters: [
			{
				id: "18",
				n: 18,
				title: "The First Circles"
			},
			{
				id: "19",
				n: 19,
				title: "Year Five of King Yezmir"
			},
			{
				id: "20",
				n: 20,
				title: "Whispers of the Labyrinth"
			},
			{
				id: "21",
				n: 21,
				title: "Mirrors Under Zilla"
			},
			{
				id: "22",
				n: 22,
				title: "The Tablets That Choose You"
			},
			{
				id: "23",
				n: 23,
				title: "The Priest Who Asked Wrong"
			}
		]
	},
	{
		id: "keys",
		numeral: "IV",
		title: "Keys in the Dark",
		frame: "Cliffs, high boughs, a harbor without a ferryman, and a boundary.",
		chapters: [
			{
				id: "24",
				n: 24,
				title: "The Old Rooster on the Cliff"
			},
			{
				id: "25",
				n: 25,
				title: "Linda of the High Boughs"
			},
			{
				id: "26",
				n: 26,
				title: "Bones of First Light"
			},
			{
				id: "27",
				n: 27,
				title: "Harbor Without a Ferryman"
			},
			{
				id: "28",
				n: 28,
				title: "Linda in the Green Teeth"
			},
			{
				id: "29",
				n: 29,
				title: "Steel and Shadows"
			},
			{
				id: "30",
				n: 30,
				title: "The River’s Edge"
			},
			{
				id: "31",
				n: 31,
				title: "The Boundary"
			}
		]
	},
	{
		id: "marsh",
		numeral: "V",
		title: "The Marsh Speaks",
		frame: "Crow Marsh stops being scenery. Pale Dawn learns what a river can refuse.",
		chapters: [
			{
				id: "32",
				n: 32,
				title: "Marshal of the Marsh"
			},
			{
				id: "33",
				n: 33,
				title: "The Crow’s Call"
			},
			{
				id: "34",
				n: 34,
				title: "The Marsh Wakes"
			},
			{
				id: "35",
				n: 35,
				title: "Retreat of the Pale Dawn"
			},
			{
				id: "36",
				n: 36,
				title: "Tiding the War"
			},
			{
				id: "37",
				n: 37,
				title: "The Ice Queen’s Choice"
			}
		]
	},
	{
		id: "river",
		numeral: "VI",
		title: "River Lies",
		frame: "Blood on the hands, lies in the water, and the fortress beginning to fill.",
		chapters: [
			{
				id: "38",
				n: 38,
				title: "Hands in the Blood"
			},
			{
				id: "39",
				n: 39,
				title: "River Lies"
			},
			{
				id: "40",
				n: 40,
				title: "The Fortress Gathers"
			},
			{
				id: "41",
				n: 41,
				title: "March of the King"
			},
			{
				id: "42",
				n: 42,
				title: "The Queen in the Shadows"
			},
			{
				id: "43",
				n: 43,
				title: "Pilgrim’s Gate Alarm"
			}
		]
	},
	{
		id: "cross",
		numeral: "VII",
		title: "Crossroads",
		frame: "An oath spoken aloud. A road back to Zilla. A council of stone.",
		chapters: [
			{
				id: "44",
				n: 44,
				title: "Crossroads in the Marsh"
			},
			{
				id: "45",
				n: 45,
				title: "The Oath I Spoke"
			},
			{
				id: "46",
				n: 46,
				title: "The Road Back to Zilla"
			},
			{
				id: "47",
				n: 47,
				title: "Knife and Kiss"
			},
			{
				id: "48",
				n: 48,
				title: "The Council of Stone"
			}
		]
	},
	{
		id: "siege",
		numeral: "VIII",
		title: "The Siege",
		frame: "The war’s last pressure lands on the Throat beneath Cock Fortress. The companion will not tell you the price.",
		chapters: [
			{
				id: "49",
				n: 49,
				title: "The Throat Gives"
			},
			{
				id: "50",
				n: 50,
				title: "The Road of Shields"
			},
			{
				id: "51",
				n: 51,
				title: "Winter on the Parapet"
			},
			{
				id: "52",
				n: 52,
				title: "Debt Collection"
			},
			{
				id: "53",
				n: 53,
				title: "The King’s Price"
			},
			{
				id: "54",
				n: 54,
				title: "The Break in the Vessel"
			},
			{
				id: "55",
				n: 55,
				title: "Ice That Loves"
			},
			{
				id: "56",
				n: 56,
				title: "Dawn’s Edge Aftermath"
			},
			{
				id: "57",
				n: 57,
				title: "The Ledger Doesn’t Pray"
			},
			{
				id: "58",
				n: 58,
				title: "The Cliffsmith’s Rule"
			},
			{
				id: "59",
				n: 59,
				title: "The Aster Mirror"
			}
		]
	}
];
var chapterCount = acts.reduce((n, act) => n + act.chapters.length, 0);
var places = [
	{
		id: "causeway",
		name: "Reed Causeway",
		region: "Crow Marsh",
		image: "/chronicle/hero.jpg",
		body: "A ribbon of half-stone, half-log road across black water toward the Crow River. On the first day of forty, Karl’s people drop the middle of it. The marsh corrects anyone who thinks the water is safer than the arrows. He writes it down as a greeting, not a victory."
	},
	{
		id: "wetpeck",
		name: "Wet Peck",
		region: "Crow Marsh",
		image: "/chronicle/wetpeck.jpg",
		body: "The marsh seat of Old King Karl. Wet Peck fights with river, reed, mud, and ambush, and it keeps one eye on Orin — the god-turtle under the water — in the hope he stays asleep."
	},
	{
		id: "fortress",
		name: "Cock Fortress",
		region: "The Throat",
		image: "/chronicle/fortress.jpg",
		body: "The forward defense of Crowmania, crouched on its ridge between Crow Marsh, the Red Ditch approaches, and Pilgrim’s Gate. A Pi Gate is sealed beneath it. The shard-compass on Nezz’s wrist is tuned to that home-note. The Forty-Day War runs toward the siege of this place."
	},
	{
		id: "deepwell",
		name: "Deepwell",
		region: "The Stone Hills",
		image: "/chronicle/deepwell.jpg",
		body: "House of Wells. A mine-city descending through layers of contested stone, holding routes, ore, and old knowledge the other houses would prefer stayed buried."
	},
	{
		id: "pale",
		name: "Pale Dawn",
		region: "The western host",
		image: "/chronicle/pale.jpg",
		body: "Legless’s column: disciplined, oath-bound, and allied with forces that treat conquest as holy correction. They arrive looking like a tax visit. Karl says that is the dangerous part."
	}
];
var people = [
	{
		id: "nezz",
		name: "Nezz",
		role: "Prince of House Cock",
		image: "/chronicle/nezz.jpg",
		quote: "A prince should look unbothered even when he’s counting knives.",
		body: "Indigo’s tutors trained the posture. The shard-compass on his left wrist is less obedient: splinters of Glass Oath that tug when other Glass, other Gates, or other things move too fast. He rides the road between Crow Marsh and Cock Fortress with Goss at his shoulder and a dead god in his skull."
	},
	{
		id: "karl",
		name: "Karl",
		role: "Old King of Wet Peck",
		image: "/chronicle/karl.jpg",
		quote: "This wasn’t a victory. It was a greeting.",
		body: "He wears lacquered marsh-steel, not pretty plate. He counts the dead, spits a small offering to the turtle under the water, and sends his son upriver with the first word of the war. Fortresses, he says, don’t like owing rivers."
	},
	{
		id: "yezmir",
		name: "Yezmir",
		role: "The Void King",
		image: "/chronicle/yezmir.jpg",
		quote: "You built your fortress on a door and then act surprised when the draft comes through.",
		body: "Pronounced YEZ-meer. His presence presses against Nezz through silence, temptation, inheritance, and promises of merciful absence. He is not a companion. He is a pressure with a voice like old parchment, and he prefers to speak when the living are trying to be quiet."
	}
];
var names = [
	{
		name: "Indigo",
		note: "Lord of the fortress that stares down the river. His men wear cleaner plate than Karl’s. His tutors taught Nezz how to look calm."
	},
	{
		name: "Goss",
		note: "The old captain. He has not let Nezz out of arm’s reach since the rumors started sticking to the prince’s shadow."
	},
	{
		name: "Drix",
		note: "Karl’s son. The armor is still almost too clean. He carries day one up the inland road."
	},
	{
		name: "Queen Lucy",
		note: "The political marriage that binds House of Hen, and the Eastern Hills, to House of Cock."
	},
	{
		name: "Orin",
		note: "God-turtle of Crow Marsh. Twenty stories when he wishes. Karl feels him the way you feel a storm behind your shoulder, and would like him to keep napping."
	},
	{
		name: "Legless",
		note: "The name on Pale Dawn. On the second day he is still a color in the fog and the reason scouts are riding."
	}
];
var bearings = [
	{
		id: "cock",
		deg: 0,
		name: "House of Cock",
		line: "Crowmania. Cock Castle, Roost Keep, Crow Harbor, Pilgrim’s Gate, and the fortress on the Throat."
	},
	{
		id: "hen",
		deg: 51,
		name: "House of Hen",
		line: "The eastern crown. Kockenflocker and the Eastern Hills, tied to Cock by Queen Lucy’s marriage."
	},
	{
		id: "wells",
		deg: 102,
		name: "House of Wells",
		line: "Deepwell and the Stone Hills. Stone, mines, routes, and dangerous old knowledge."
	},
	{
		id: "green",
		deg: 154,
		name: "House Greenwood",
		line: "Scratch Forest and Echo Forest. Neutral crossings and older living boundaries."
	},
	{
		id: "pale",
		deg: 205,
		name: "Pale Dawn",
		line: "Legless’s host. Disciplined, oath-bound, and convinced conquest can be a holy correction."
	},
	{
		id: "choir",
		deg: 257,
		name: "The Choir",
		line: "Sound, pain, repetition, and forced response — a doctrine for studying thresholds and living vessels."
	},
	{
		id: "zilla",
		deg: 308,
		name: "Zilla",
		line: "A free city on the Echo Dome. Trade, spectacle, criminal leverage, and powers older than the arenas."
	}
];
var forces = [
	{
		id: "fire",
		name: "Fire",
		note: "A primary force. The realm records the cost, not a rank."
	},
	{
		id: "frost",
		name: "Frost",
		note: "May preserve, expose, restrain, or deny."
	},
	{
		id: "wind",
		name: "Wind",
		note: "A primary force. Felt as pressure before it is named."
	},
	{
		id: "earth",
		name: "Earth",
		note: "A primary force. Stone keeps its own counsel, especially under Deepwell."
	},
	{
		id: "void",
		name: "Void",
		note: "Speed, silence, absence, and merciful escape. An agenda, not a morality. Yezmir’s country."
	},
	{
		id: "light",
		name: "Light",
		note: "Holy is a force with an agenda, not an automatic good. Arcolos is dawn, oath, judgment, protection, and the terrible mercy of light."
	},
	{
		id: "sound",
		name: "Sound",
		note: "The Choir’s instrument: repetition, pain, and a response that is not quite a choice."
	},
	{
		id: "lightning",
		name: "Lightning",
		note: "A primary force. The oath attached to it is the part that matters."
	},
	{
		id: "water",
		name: "Water",
		note: "A primary force, and the marsh’s oldest argument. On the causeway it is made to boil. Orin is not consulted."
	}
];
var doctrines = [
	{
		name: "Glass Oath",
		note: "A binding spiritual contract. Power comes through an element, a deity, or a governing principle, and every oath carries an obligation. Breaking one, bending one, or exploiting one has a spiritual cost and a practical one."
	},
	{
		name: "Echo",
		note: "The pressure of a person’s power, emotion, oath-condition, and intent. Echoes are sensed. They are never measured as a number."
	},
	{
		name: "Pi Gate",
		note: "A sealed threshold under the deeper conflict. Old warnings say it is not opened by force, blood, or command. It judges."
	},
	{
		name: "Shard-compass",
		note: "Splinters of Glass Oath bound in leather and thread, tuned to the Pi Gate beneath Cock Fortress. Less a north and more a home-note. It tugs."
	},
	{
		name: "Choice-trace",
		note: "The residue of a consequential decision: oath, betrayal, mercy, refusal, or sacrifice."
	},
	{
		name: "Arcolos",
		note: "AR-koh-lohs. Holy god of Squack’Ka’Saar. Dawn, oath, judgment, protection, and the terrible mercy of light."
	}
];
var DB_NAME = "war-of-fate-score";
var STORE = "tracks";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Could not open the score."));
	});
}
async function listTracks() {
	if (typeof indexedDB === "undefined") return [];
	const db = await openDb();
	const rows = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return rows.map(({ data: _data, ...meta }) => meta).sort((a, b) => a.created - b.created);
}
async function getTrack(id) {
	if (typeof indexedDB === "undefined") return null;
	const db = await openDb();
	const row = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get(id);
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return row ?? null;
}
async function putTrack(track) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.objectStore(STORE).put(track);
	});
	db.close();
}
async function patchTrack(id, patch) {
	const existing = await getTrack(id);
	if (!existing) return;
	await putTrack({
		...existing,
		...patch
	});
}
async function deleteTrack(id) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.objectStore(STORE).delete(id);
	});
	db.close();
}
var urls = /* @__PURE__ */ new Map();
var audio = null;
var onEnded = () => {};
function getAudio() {
	if (typeof window === "undefined") return null;
	if (!audio) {
		audio = new Audio();
		audio.preload = "auto";
		audio.addEventListener("ended", () => onEnded());
	}
	return audio;
}
function setOnEnded(fn) {
	onEnded = fn;
}
function setVolume(volume) {
	const el = getAudio();
	if (el) el.volume = volume;
}
async function playStored(track, volume) {
	const el = getAudio();
	if (!el) return;
	let url = urls.get(track.id);
	if (!url) {
		const copy = track.data.slice(0);
		url = URL.createObjectURL(new Blob([copy], { type: track.mime || "audio/mpeg" }));
		urls.set(track.id, url);
	}
	if (el.src !== url) el.src = url;
	el.volume = volume;
	await el.play();
}
function pauseAudio() {
	getAudio()?.pause();
}
function resumeAudio() {
	return getAudio()?.play();
}
function forgetUrl(id) {
	const url = urls.get(id);
	if (!url) return;
	if (audio && audio.src === url) {
		audio.pause();
		audio.removeAttribute("src");
		audio.load();
	}
	URL.revokeObjectURL(url);
	urls.delete(id);
}
var ctx = null;
var noise = null;
var oscA = null;
var oscB = null;
var master = null;
function stopAtmosphere() {
	try {
		noise?.stop();
	} catch {}
	try {
		oscA?.stop();
	} catch {}
	try {
		oscB?.stop();
	} catch {}
	noise = null;
	oscA = null;
	oscB = null;
	master?.disconnect();
	master = null;
}
async function startAtmosphere() {
	stopAtmosphere();
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return;
	ctx = ctx ?? new AC();
	if (ctx.state === "suspended") await ctx.resume();
	master = ctx.createGain();
	master.gain.value = .04;
	master.connect(ctx.destination);
	const length = ctx.sampleRate * 2;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const channel = buffer.getChannelData(0);
	for (let i = 0; i < length; i += 1) channel[i] = Math.random() * 2 - 1;
	noise = ctx.createBufferSource();
	noise.buffer = buffer;
	noise.loop = true;
	const filter = ctx.createBiquadFilter();
	filter.type = "lowpass";
	filter.frequency.value = 380;
	const noiseGain = ctx.createGain();
	noiseGain.gain.value = .4;
	noise.connect(filter);
	filter.connect(noiseGain);
	noiseGain.connect(master);
	noise.start();
	const tone = (freq, gain) => {
		const osc = ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.value = freq;
		const g = ctx.createGain();
		g.gain.value = gain;
		osc.connect(g);
		g.connect(master);
		osc.start();
		return osc;
	};
	oscA = tone(73, .22);
	oscB = tone(110, .08);
}
var READ_KEY = "wof-read";
var VOL_KEY = "wof-vol";
function playOrder(tracks) {
	const cued = acts.map((act) => tracks.find((track) => track.actId === act.id)).filter((track) => Boolean(track));
	const loose = tracks.filter((track) => !track.actId);
	return [...cued, ...loose];
}
var useChronicle = create((set, get) => ({
	view: "cover",
	actId: acts[0].id,
	placeId: null,
	forceId: "void",
	read: [],
	tracks: [],
	currentId: null,
	playing: false,
	volume: .85,
	atmosphere: false,
	armedDelete: null,
	setView: (view) => {
		set({ view });
		if (typeof window !== "undefined") window.scrollTo(0, 0);
	},
	setAct: (actId) => set({ actId }),
	setPlace: (placeId) => set({ placeId }),
	setForce: (forceId) => set({ forceId }),
	toggleRead: (id) => {
		const read = get().read.includes(id) ? get().read.filter((item) => item !== id) : [...get().read, id];
		set({ read });
		try {
			localStorage.setItem(READ_KEY, JSON.stringify(read));
		} catch {}
	},
	hydrate: async () => {
		let volume = get().volume;
		let read = [];
		try {
			const storedVol = localStorage.getItem(VOL_KEY);
			if (storedVol) {
				const n = Number(storedVol);
				if (!Number.isNaN(n)) volume = Math.min(1, Math.max(0, n));
			}
			const storedRead = localStorage.getItem(READ_KEY);
			if (storedRead) {
				const parsed = JSON.parse(storedRead);
				if (Array.isArray(parsed)) read = parsed.filter((item) => typeof item === "string");
			}
		} catch {}
		setVolume(volume);
		const tracks = await listTracks();
		set({
			volume,
			read,
			tracks
		});
		setOnEnded(() => {
			const state = get();
			const order = playOrder(state.tracks);
			const next = order[order.findIndex((track) => track.id === state.currentId) + 1];
			if (next) state.play(next.id);
			else set({ playing: false });
		});
	},
	addFiles: async (files, actId = null) => {
		const list = Array.from(files).filter((file) => file.type.startsWith("audio/") || /\.(mp3|m4a|aac|wav|ogg|flac|opus)$/i.test(file.name));
		let hold = actId ? get().tracks.find((track) => track.actId === actId)?.id ?? null : null;
		for (const file of list) {
			const data = await file.arrayBuffer();
			const id = crypto.randomUUID();
			if (hold) {
				await patchTrack(hold, { actId: null });
				hold = null;
			}
			await putTrack({
				id,
				name: file.name.replace(/\.[^/.]+$/, ""),
				actId,
				mime: file.type || "audio/mpeg",
				created: Date.now(),
				data
			});
			if (actId) hold = id;
		}
		set({ tracks: await listTracks() });
	},
	assign: async (id, actId) => {
		if (actId) {
			const holder = get().tracks.find((track) => track.actId === actId && track.id !== id);
			if (holder) await patchTrack(holder.id, { actId: null });
		}
		await patchTrack(id, { actId });
		set({ tracks: await listTracks() });
	},
	rename: async (id, name) => {
		const trimmed = name.trim();
		if (!trimmed) return;
		await patchTrack(id, { name: trimmed });
		set({ tracks: await listTracks() });
	},
	remove: async (id) => {
		forgetUrl(id);
		await deleteTrack(id);
		const tracks = await listTracks();
		const currentId = get().currentId === id ? null : get().currentId;
		set({
			tracks,
			currentId,
			playing: currentId ? get().playing : false,
			armedDelete: null
		});
	},
	armDelete: (id) => set({ armedDelete: id }),
	play: async (id) => {
		const track = await getTrack(id);
		if (!track) return;
		try {
			await playStored(track, get().volume);
			set({
				currentId: id,
				playing: true
			});
		} catch {
			set({
				currentId: id,
				playing: false
			});
		}
	},
	toggle: async (id) => {
		const state = get();
		const target = id ?? state.currentId;
		if (!target) {
			const first = playOrder(state.tracks)[0];
			if (first) await state.play(first.id);
			return;
		}
		if (state.currentId === target && state.playing) {
			pauseAudio();
			set({ playing: false });
			return;
		}
		if (state.currentId === target && !state.playing) {
			try {
				await resumeAudio();
				set({ playing: true });
			} catch {
				await state.play(target);
			}
			return;
		}
		await state.play(target);
	},
	next: async () => {
		const order = playOrder(get().tracks);
		if (!order.length) return;
		const next = order[(order.findIndex((track) => track.id === get().currentId) + 1) % order.length];
		if (next) await get().play(next.id);
	},
	prev: async () => {
		const order = playOrder(get().tracks);
		if (!order.length) return;
		const prev = order[(order.findIndex((track) => track.id === get().currentId) - 1 + order.length) % order.length];
		if (prev) await get().play(prev.id);
	},
	setVol: (volume) => {
		const next = Math.min(1, Math.max(0, volume));
		setVolume(next);
		set({ volume: next });
		try {
			localStorage.setItem(VOL_KEY, String(next));
		} catch {}
	},
	toggleAtmosphere: async () => {
		if (get().atmosphere) {
			stopAtmosphere();
			set({ atmosphere: false });
			return;
		}
		await startAtmosphere();
		set({ atmosphere: true });
	}
}));
function CoverView() {
	const setView = useChronicle((s) => s.setView);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/chronicle/hero.jpg",
				alt: "Reed Causeway at dawn, fog over black water, a rooster king watching a pale column",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-ink via-ink/75 to-ink/30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-36 bg-linear-to-b from-ink to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-dvh flex-col justify-end px-5 pt-28 pb-44 md:px-10 md:pb-36",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-widest text-dawn",
						children: [
							book.series,
							" · ",
							book.volume
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-4xl font-display text-6xl leading-none text-balance text-bone md:text-8xl",
						children: book.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-display text-2xl italic text-bone md:text-3xl",
						children: book.motto
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 max-w-prose text-lg text-pretty text-bone/90",
						children: [
							summary[0],
							" ",
							summary[1]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm uppercase tracking-widest text-mist",
						children: [
							book.author,
							" · ",
							book.imprint
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView("ledger"),
								className: "min-h-11 bg-dawn px-5 py-3 font-display text-ink",
								children: "Open the ledger"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView("realm"),
								className: "min-h-11 border border-dawn/50 px-5 py-3 font-display text-bone",
								children: "Walk the realm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOpen((v) => !v),
								className: "min-h-11 px-5 py-3 font-display text-dawn",
								"aria-expanded": open,
								children: open ? "Close the first line" : "The first line"
							})
						]
					}),
					open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "mt-8 max-w-prose border-l border-dawn pl-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl italic text-balance text-bone",
							children: opening.line
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
							className: "mt-2 text-sm text-mist",
							children: opening.attr
						})]
					})
				]
			})
		]
	});
}
function LedgerView() {
	const actId = useChronicle((s) => s.actId);
	const setAct = useChronicle((s) => s.setAct);
	const read = useChronicle((s) => s.read);
	const toggleRead = useChronicle((s) => s.toggleRead);
	const tracks = useChronicle((s) => s.tracks);
	const toggle = useChronicle((s) => s.toggle);
	const setView = useChronicle((s) => s.setView);
	const act = acts.find((item) => item.id === actId) ?? acts[0];
	const cue = tracks.find((track) => track.actId === act.id);
	const marked = read.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-dawn",
			children: "The ledger"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-display text-4xl text-balance text-bone md:text-5xl",
			children: "What the war is, before it spends you"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 max-w-prose space-y-5 text-lg leading-relaxed text-pretty",
			children: summary.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph.slice(0, 24)))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 max-w-prose text-mist",
			children: "The contents below are the book's own. Mark a chapter when you have read it — the marks stay in this browser. This companion does not tell you how the forty days end."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 flex items-end justify-between gap-4 border-t border-dawn/20 pt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-lg text-bone",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-dawn",
					children: marked
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-mist",
					children: [
						" of ",
						chapterCount,
						" marked"
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-px bg-dawn/20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-px bg-dawn",
				style: { width: `${marked / chapterCount * 100}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 -mx-5 flex gap-2 overflow-x-auto px-5 pb-2 md:mx-0 md:flex-wrap md:px-0",
			children: acts.map((item) => {
				const active = item.id === act.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setAct(item.id),
					className: active ? "shrink-0 border border-dawn bg-dawn px-4 py-3 text-left text-ink" : "shrink-0 border border-dawn/30 px-4 py-3 text-left text-bone",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-xs uppercase tracking-widest",
						children: ["Act ", item.numeral]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-lg",
						children: item.title
					})]
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 border-t border-dawn/20 pt-6",
			"aria-labelledby": "act-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-widest text-dawn",
					children: ["Act ", act.numeral]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					id: "act-title",
					className: "mt-2 font-display text-3xl text-balance",
					children: act.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose text-lg text-pretty text-mist",
					children: act.frame
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-3",
					children: cue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void toggle(cue.id),
						className: "min-h-11 border border-dawn/40 px-4 py-2 font-display text-dawn",
						children: [
							"Play “",
							cue.name,
							"”"
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setView("score"),
						className: "min-h-11 border border-dawn/30 px-4 py-2 font-display text-mist",
						children: "Lay a cue on this act"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 divide-y divide-dawn/15 border-y border-dawn/15",
					children: act.chapters.map((chapter) => {
						const on = read.includes(chapter.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": on,
								"aria-label": on ? `Unmark chapter ${chapter.n}` : `Mark chapter ${chapter.n} read`,
								onClick: () => toggleRead(chapter.id),
								className: on ? "flex size-11 shrink-0 items-center justify-center rounded-full border border-dawn bg-dawn/15" : "flex size-11 shrink-0 items-center justify-center rounded-full border border-dawn/35",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: on ? "size-2.5 rounded-full bg-dawn" : "size-2.5 rounded-full border border-dawn/40" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs tabular-nums text-mist",
									children: ["Chapter ", chapter.n]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: on ? "font-display text-xl text-dawn" : "font-display text-xl text-bone",
									children: chapter.title
								})]
							})]
						}, chapter.id);
					})
				})
			]
		})
	] });
}
function RealmView() {
	const placeId = useChronicle((s) => s.placeId);
	const setPlace = useChronicle((s) => s.setPlace);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-dawn",
			children: "The realm"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 max-w-3xl font-display text-4xl text-balance md:text-5xl",
			children: "Squack'Ka'Saar, before the maps argue"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-prose text-lg text-pretty text-mist",
			children: "Five places from the opening of the war. Tap a plate. The rest of the realm is named further down, where the book has not yet asked for a portrait."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-6 md:grid-cols-2",
			children: places.map((place) => {
				const open = placeId === place.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "border border-dawn/20 bg-panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setPlace(open ? null : place.id),
						className: "block w-full text-left",
						"aria-expanded": open,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: place.image,
							alt: place.name,
							className: "aspect-video w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-dawn",
								children: place.region
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-display text-2xl",
								children: place.name
							})]
						})]
					}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pb-5 text-pretty leading-relaxed text-mist",
						children: place.body
					})]
				}, place.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-14 font-display text-3xl",
			children: "Who is already in the fog"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-8 md:grid-cols-3",
			children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
				person.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: person.image,
					alt: person.name,
					className: "portrait w-full object-cover object-top"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs uppercase tracking-widest text-dawn",
					children: person.role
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-3xl",
					children: person.name
				}),
				person.quote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "mt-3 border-l border-dawn pl-3 font-display text-lg italic text-pretty",
					children: person.quote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-pretty leading-relaxed text-mist",
					children: person.body
				})
			] }, person.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-14 font-display text-3xl",
			children: "Also on the first pages"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-dawn/15 border-y border-dawn/15",
			children: names.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-1 py-4 md:grid-cols-[10rem_1fr] md:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: entry.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-pretty text-mist",
					children: entry.note
				})]
			}, entry.name))
		})
	] });
}
function distance(a, b) {
	const d = Math.abs(a - b) % 360;
	return d > 180 ? 360 - d : d;
}
function OathsView() {
	const forceId = useChronicle((s) => s.forceId);
	const setForce = useChronicle((s) => s.setForce);
	const [deg, setDeg] = (0, import_react.useState)(18);
	const drag = (0, import_react.useRef)(false);
	const dial = (0, import_react.useRef)(null);
	const force = forces.find((item) => item.id === forceId) ?? forces[0];
	const nearest = bearings.reduce((best, item) => distance(deg, item.deg) < distance(deg, best.deg) ? item : best);
	const heard = distance(deg, nearest.deg) < 26;
	function fromEvent(clientX, clientY) {
		const el = dial.current;
		if (!el) return deg;
		const rect = el.getBoundingClientRect();
		const cx = rect.left + rect.width / 2;
		const cy = rect.top + rect.height / 2;
		let next = Math.atan2(clientX - cx, cy - clientY) * 180 / Math.PI;
		if (next < 0) next += 360;
		return next;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-dawn",
			children: "Oaths"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 max-w-3xl font-display text-4xl text-balance md:text-5xl",
			children: "It does not point north"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-prose text-lg text-pretty text-mist",
			children: "The shard-compass is splinters of Glass Oath in leather, tuned to the Pi Gate under Cock Fortress. Turn it. When it tugs close to a house, the house answers."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid items-center gap-8 md:grid-cols-[18rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: dial,
				role: "slider",
				tabIndex: 0,
				"aria-valuemin": 0,
				"aria-valuemax": 359,
				"aria-valuenow": Math.round(deg),
				"aria-label": "Shard-compass",
				className: "relative mx-auto size-64 touch-none rounded-full border border-dawn/40 bg-ink",
				onPointerDown: (event) => {
					drag.current = true;
					event.currentTarget.setPointerCapture(event.pointerId);
					setDeg(fromEvent(event.clientX, event.clientY));
				},
				onPointerMove: (event) => {
					if (!drag.current) return;
					setDeg(fromEvent(event.clientX, event.clientY));
				},
				onPointerUp: () => {
					drag.current = false;
				},
				onKeyDown: (event) => {
					if (event.key === "ArrowRight" || event.key === "ArrowUp") {
						event.preventDefault();
						setDeg((value) => (value + 12) % 360);
					}
					if (event.key === "ArrowLeft" || event.key === "ArrowDown") {
						event.preventDefault();
						setDeg((value) => (value - 12 + 360) % 360);
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/chronicle/compass.jpg",
						alt: "",
						className: "absolute top-1/2 left-1/2 size-24 -translate-x-1/2 -translate-y-1/2 rounded-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute inset-0",
						style: { transform: `rotate(${deg}deg)` },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 left-1/2 h-28 w-px -translate-x-1/2 bg-dawn" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute top-2 left-1/2 -translate-x-1/2 text-xs text-dawn",
						children: "tug"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: heard ? "The tug lands" : "Still searching"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-display text-3xl",
					children: heard ? nearest.name : "Between oaths"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose text-lg text-pretty text-mist",
					children: heard ? nearest.line : "Houses sit on the dial like old debts. Drag the glass, or choose one below."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: bearings.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDeg(item.deg),
						className: heard && nearest.id === item.id ? "min-h-11 border border-dawn bg-dawn px-3 py-2 text-ink" : "min-h-11 border border-dawn/30 px-3 py-2 text-bone",
						children: item.name
					}, item.id))
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-14 font-display text-3xl",
			children: "Primary forces"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-prose text-mist",
			children: "Holy and Void have agendas. They are not automatic moral alignments. Nothing here has a level."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid gap-2 sm:grid-cols-3",
			children: forces.map((item) => {
				const active = item.id === force.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setForce(item.id),
					className: active ? "min-h-11 border border-dawn bg-dawn/10 px-4 py-3 text-left font-display text-xl text-dawn" : "min-h-11 border border-dawn/25 px-4 py-3 text-left font-display text-xl text-bone",
					"aria-pressed": active,
					children: item.name
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-prose text-lg text-pretty",
			children: force.note
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-14 font-display text-3xl",
			children: "What the words are holding"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-dawn/15 border-y border-dawn/15",
			children: doctrines.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-2 py-5 md:grid-cols-[12rem_1fr] md:gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl text-dawn",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-pretty leading-relaxed",
					children: item.note
				})]
			}, item.name))
		})
	] });
}
function ScoreView() {
	const tracks = useChronicle((s) => s.tracks);
	const addFiles = useChronicle((s) => s.addFiles);
	const assign = useChronicle((s) => s.assign);
	const rename = useChronicle((s) => s.rename);
	const remove = useChronicle((s) => s.remove);
	const armedDelete = useChronicle((s) => s.armedDelete);
	const armDelete = useChronicle((s) => s.armDelete);
	const toggle = useChronicle((s) => s.toggle);
	const currentId = useChronicle((s) => s.currentId);
	const playing = useChronicle((s) => s.playing);
	const atmosphere = useChronicle((s) => s.atmosphere);
	const toggleAtmosphere = useChronicle((s) => s.toggleAtmosphere);
	const [over, setOver] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-dawn",
			children: "The score"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-display text-4xl text-balance md:text-5xl",
			children: "Lay the soundtrack in"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-prose text-lg text-pretty text-mist",
			children: "Add music from the book's soundtrack. It stays in this browser and is never uploaded. Assign a movement to an act and it will be waiting when you open that part of the ledger."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			onDragOver: (event) => {
				event.preventDefault();
				setOver(true);
			},
			onDragLeave: () => setOver(false),
			onDrop: (event) => {
				event.preventDefault();
				setOver(false);
				addFiles(event.dataTransfer.files);
			},
			className: over ? "mt-8 flex min-h-36 cursor-pointer flex-col items-center justify-center border border-dawn bg-dawn/10 px-6 py-8 text-center" : "mt-8 flex min-h-36 cursor-pointer flex-col items-center justify-center border border-dashed border-dawn/40 px-6 py-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-5 text-dawn",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-3 font-display text-2xl",
					children: "Add tracks"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 text-mist",
					children: "Drop audio here, or choose files"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus",
					multiple: true,
					className: "sr-only",
					onChange: (event) => {
						if (event.target.files) addFiles(event.target.files);
						event.target.value = "";
					}
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap items-center justify-between gap-3 border border-dawn/20 px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl",
				children: "Marsh room-tone"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "A quiet bed of water and low strings until your score takes the room. Not part of the soundtrack."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void toggleAtmosphere(),
				"aria-pressed": atmosphere,
				className: atmosphere ? "min-h-11 bg-dawn px-4 py-2 font-display text-ink" : "min-h-11 border border-dawn/40 px-4 py-2 font-display text-bone",
				children: atmosphere ? "Silence the marsh" : "Let the marsh breathe"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-12 font-display text-2xl",
			children: "Cues"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-dawn/15 border-y border-dawn/15",
			children: acts.map((act) => {
				const cue = tracks.find((track) => track.actId === act.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs uppercase tracking-widest text-dawn",
							children: ["Act ", act.numeral]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: act.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mist",
							children: cue ? cue.name : "Empty"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [cue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void toggle(cue.id),
							className: "flex size-11 items-center justify-center border border-dawn/40 text-dawn",
							"aria-label": playing && currentId === cue.id ? `Pause ${cue.name}` : `Play ${cue.name}`,
							children: playing && currentId === cue.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
								className: "size-4",
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "min-h-11 cursor-pointer border border-dawn/30 px-3 py-2 text-sm text-bone",
							children: [cue ? "Replace" : "Lay in", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus",
								className: "sr-only",
								onChange: (event) => {
									if (event.target.files) addFiles(event.target.files, act.id);
									event.target.value = "";
								}
							})]
						})]
					})]
				}, act.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-12 font-display text-2xl",
			children: "Library"
		}),
		tracks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-mist",
			children: "Nothing in the library yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-dawn/15 border-y border-dawn/15",
			children: tracks.map((track) => {
				const live = currentId === track.id && playing;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 py-4 md:grid-cols-[auto_1fr_auto] md:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void toggle(track.id),
							className: "flex size-11 items-center justify-center border border-dawn/40 text-dawn",
							"aria-label": live ? `Pause ${track.name}` : `Play ${track.name}`,
							children: live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [editing === track.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								defaultValue: track.name,
								"aria-label": "Track name",
								className: "w-full border border-dawn/40 bg-ink px-3 py-2 text-bone",
								onBlur: (event) => {
									rename(track.id, event.target.value);
									setEditing(null);
								},
								onKeyDown: (event) => {
									if (event.key === "Enter") event.currentTarget.blur();
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setEditing(track.id),
								className: "block max-w-full truncate text-left font-display text-xl",
								children: track.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-sm text-mist",
								children: ["Cue", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: track.actId ?? "",
									onChange: (event) => void assign(track.id, event.target.value || null),
									className: "mt-1 block w-full border border-dawn/30 bg-ink px-3 py-2 text-bone",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Unassigned"
									}), acts.map((act) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: act.id,
										children: [
											"Act ",
											act.numeral,
											" — ",
											act.title
										]
									}, act.id))]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (armedDelete === track.id) remove(track.id);
								else armDelete(track.id);
							},
							className: "min-h-11 justify-self-start px-2 text-sm text-mist md:justify-self-end",
							children: armedDelete === track.id ? "Remove this track?" : "Remove"
						})
					]
				}, track.id);
			})
		})
	] });
}
function format(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	const whole = Math.floor(seconds);
	return `${Math.floor(whole / 60)}:${(whole % 60).toString().padStart(2, "0")}`;
}
function PlayerDock() {
	const tracks = useChronicle((s) => s.tracks);
	const currentId = useChronicle((s) => s.currentId);
	const playing = useChronicle((s) => s.playing);
	const volume = useChronicle((s) => s.volume);
	const toggle = useChronicle((s) => s.toggle);
	const next = useChronicle((s) => s.next);
	const prev = useChronicle((s) => s.prev);
	const setVol = useChronicle((s) => s.setVol);
	const setView = useChronicle((s) => s.setView);
	const [time, setTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const current = tracks.find((track) => track.id === currentId) ?? null;
	const act = current?.actId ? acts.find((item) => item.id === current.actId) : null;
	(0, import_react.useEffect)(() => {
		const el = getAudio();
		if (!el) return;
		const onTime = () => setTime(el.currentTime);
		const onMeta = () => setDuration(el.duration);
		el.addEventListener("timeupdate", onTime);
		el.addEventListener("durationchange", onMeta);
		el.addEventListener("loadedmetadata", onMeta);
		return () => {
			el.removeEventListener("timeupdate", onTime);
			el.removeEventListener("durationchange", onMeta);
			el.removeEventListener("loadedmetadata", onMeta);
		};
	}, [currentId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl items-center gap-3 px-3 py-2 md:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void prev(),
				className: "flex size-11 items-center justify-center text-mist",
				"aria-label": "Previous track",
				disabled: !tracks.length,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void toggle(),
				className: "flex size-11 items-center justify-center bg-dawn text-ink",
				"aria-label": playing ? "Pause" : "Play",
				disabled: !tracks.length,
				children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void next(),
				className: "flex size-11 items-center justify-center text-mist",
				"aria-label": "Next track",
				disabled: !tracks.length,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setView("score"),
				className: "min-w-0 flex-1 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-display text-base text-bone",
					children: current ? current.name : "The score is empty"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-mist",
					children: current ? act ? `Act ${act.numeral} · ${act.title}` : "Unassigned" : "Add the book’s soundtrack"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "hidden items-center gap-2 text-xs text-mist md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: format(time)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: duration || 0,
						step: .1,
						value: Math.min(time, duration || 0),
						"aria-label": "Seek",
						disabled: !current || !duration,
						onChange: (event) => {
							const el = getAudio();
							if (!el) return;
							el.currentTime = Number(event.target.value);
							setTime(el.currentTime);
						},
						className: "w-28 accent-dawn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: format(duration)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .01,
						value: volume,
						"aria-label": "Volume",
						onChange: (event) => setVol(Number(event.target.value)),
						className: "w-16 accent-dawn"
					})
				]
			})
		]
	});
}
var nav = [
	{
		id: "cover",
		label: "Dawn",
		icon: BookOpen
	},
	{
		id: "ledger",
		label: "Ledger",
		icon: ScrollText
	},
	{
		id: "realm",
		label: "Realm",
		icon: Map$1
	},
	{
		id: "oaths",
		label: "Oaths",
		icon: Compass
	},
	{
		id: "score",
		label: "Score",
		icon: AudioLines
	}
];
function ChronicleApp() {
	const view = useChronicle((s) => s.view);
	const setView = useChronicle((s) => s.setView);
	const hydrate = useChronicle((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-ink text-bone",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: view === "cover" ? "absolute inset-x-0 top-0 z-20 flex items-center justify-between gap-4 px-5 py-4 md:px-10" : "sticky top-0 z-20 flex items-center justify-between gap-4 border-b border-dawn/20 bg-ink/95 px-5 py-4 backdrop-blur-sm md:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setView("cover"),
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-lg leading-none text-bone md:text-xl",
						children: book.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs uppercase tracking-widest text-dawn",
						children: book.series
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					"aria-label": "Companion",
					children: nav.map((item) => {
						const active = view === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setView(item.id),
							className: active ? "border-b border-dawn px-3 py-2 font-display text-bone" : "border-b border-transparent px-3 py-2 font-display text-mist hover:text-bone",
							"aria-current": active ? "page" : void 0,
							children: item.label
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: view === "cover" ? "" : "mx-auto max-w-5xl px-5 pt-8 pb-40 md:px-10 md:pt-12 md:pb-28",
				children: [
					view === "cover" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverView, {}),
					view === "ledger" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerView, {}),
					view === "realm" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RealmView, {}),
					view === "oaths" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OathsView, {}),
					view === "score" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreView, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dock fixed inset-x-0 bottom-0 z-30 border-t border-dawn/20 bg-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDock, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "grid grid-cols-5 border-t border-dawn/15 md:hidden",
					"aria-label": "Companion",
					children: nav.map((item) => {
						const Icon = item.icon;
						const active = view === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setView(item.id),
							className: active ? "flex min-h-16 flex-col items-center justify-center gap-1 text-dawn" : "flex min-h-16 flex-col items-center justify-center gap-1 text-mist",
							"aria-current": active ? "page" : void 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: item.label
							})]
						}, item.id);
					})
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChronicleApp, {});
}
//#endregion
export { Home as component };
